<?php
$servername = "localhost";
$username = "root";
$password = "mysql";
$dbase = "second_hand";
// Create connection
$conn = new mysqli($servername, $username, $password , $dbase);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "";
?>
<!DOCTPE html>
<html>
	<head>
	<link rel="stylesheet"  type="text/css" href="style.css" />
	<style> 
		  
		h1{color:black; 
		text-align:center;
		position:absolute; left:300px; top: 50px;
		}
		.fields{
		margin-left:40px;}
		#heading { padding: 10px;
		padding-left: 17px;	
		margin-left: 1px; 
		margin-top: 2px; }
		p{padding: 10px;
		color : black;  
		margin-top: 20px; 
		}
		fieldset{background:white;
		padding: 10px;
		padding-left: 17px;	
		margin-left: 1px; 
		margin-top: 20px;
		margin-bottom: 20px;}
		.error {color: #FF0000;}
    </style>
	
		<link rel="stylesheet"  type="text/css" href="style.css" />
	</head>
		<body class="body">	
		<img id=heading src= "website.png" width="200" Height="200">
		<div class="search-container">
		<form>
		<input type="text" placeholder="Search.." name="search">
		<button type="submit">Go!</button>
		</form>
		</div>
		
		<div class="topnav">
		<a href="index.html">Home</a>
		<a href="services.php">Services</a>
		<a class="active" href="#requests">Requests</a>
		<a href="activity.html">My Activity</a>
		<a style="position:absolute; right:10px;">Log In</a>
		<a style="position:absolute; right:90px;" >Sign Up</a>
		</div>
		
		<h1> Fill the form and we will help you </h1>
		<fieldset>
		<legend style="font-size: 1.9em;"> Request Form </legend>
		<form id="req" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">			
				<p><span class="error">* Required field</span></p>
				<br>
				<label> First name : </label>
				<input class=fields id="Firstname" name="fname" type="text" placeholder="Enter your first name">
				<span class="error">* <?php echo $fnameErr;?></span>
				<br>
				<br>
				<label> Last name : </label>
				<input class=fields id="Lastname" name ="lname" type="text" placeholder="Enter your last name">
				<span class="error">* <?php echo $lnameErr;?></span>
				<br>
				<br>
				<label> Phone Number : </label>
				<input style="margin-left:10px;" class=fields id="phone" name ="phone" type="text"  placeholder="Enter your Phone number">
				<span class="error">* <?php echo $phoneErr;?></span>
				<br>
				<br>
				<label> E-mail Address : </label>
				<input style="margin-left:8px;" id="Email"  name="email" type="text"  placeholder="Enter your e-mail address">
				<span class="error">* <?php echo $emailErr;?></span>
				<br>
				<br>
				<label> Requests details : </label>
				<input style="padding-bottom:50px;" id="details" name="requestdet" type="text"  placeholder="Enter your requests details">
				<span class="error">* <?php echo  $requestdetErr ;?></span>
				<br>
				<br>
				Preferred document type : <span class="error">* <?php echo  $documentErr ;?></span> 
		        <br>
				<input   id="HC" name="document" type="checkbox" value="Hard Copy" >Hard Copy</input>
				<br>
				<input  id="pdf" name="document" type="checkbox" value="PDF" >PDF</input>
				<br>
				<input  id="w_OR_p" name="document" type="checkbox" value="Word or PowerPoint" >Word or PowerPoint</input>
				<br>
				<input  id="others" name="document" type="checkbox" value="Other" >Other</input>
				<br>
				<br>
				 Would you like to ? <span class="error">* <?php echo  $paymentErr ;?></span> 
				 <br>
				<input id="pay" name="payment" type="radio" value="Pay for it" >Pay for it</input>
				<br>
				<input id="free" name="payment" type="radio" value="Get it free" >Get it free</input>
				<br>
				<input id="any" name="payment" type="radio" value="Any of them" >Any of them</input>
				<br>
				<br>
				Choose the related colleage : <span class="error">* <?php echo  $colleageErr ;?></span>
				<br>
				<select id="college" name="colleage">
				<option value="Faculty of Computing and information technology">FCIT - Faculty of Computing and information technology</option>
				<option  value="Faculty of sience">Faculty of Science</option>
				<option  value="Faculty of Bessuniess and adminstration">FEA - Faculty of Economics and Adminstration</option>
				</select>
				<br>
				<br>
				
				<button  style="margin-top:0px;" id="submit"   name="submit"  type="submit" class="btn btn-secondary" onclick=" return ConfirmFunction(); false" >Submit</button>
				<button  id="reset"  type="reset"  class="btn btn-secondary" >Clear</button>
			<p id="hintText"></p>
			</form>	
			
		</fieldset>
		
		
		
		
		
		
				<?php
// define variables and set to empty values
		 
	

	function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
	}
$fname = $lname = $email = $phone =  $requestdet = $document = $payment = $colleage = "";
$fnameErr = $lnameErr = $emailErr = $phoneErr =  $requestdetErr = $documentErr = $paymentErr = $colleageErr = "";
 $check = false;      
		
		
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			
            if (!empty($_POST['fname'])) {
               $fname = test_input($_POST['fname']);
			   
			     if (!empty($_POST['lname'])) {
					 $lname = test_input($_POST['lname']);
					 
					 if (!empty($_POST['email'])) { 
					 $email = test_input($_POST['email']);	
					 
					 if (!empty($_POST['phone'])) {
						  $phone = (int) test_input($_POST['phone']);
						  
						  if (!empty($_POST['requestdet'])){
							  $requestdet  = test_input($_POST['requestdet']);
							  
							 if (isset($_POST['document'])) {
							 $document = $_POST['document'];
							 $documentErr = "You must select at least one";
							
								if (isset($_POST['payment'])) {
								$payment = $_POST['payment'];
							
									if (isset($_POST['colleage'])) {
									$colleage = $_POST['colleage'];
									$check = TRUE;
									}else{
									$colleageErr = "Please select a colleage";	
									}
							
								}else{
								$paymentErr = "please choose one";
								}
							
							}else{
								$documentErr = "You must select at least one";
							}
							
						  }else{
							 $requestdetErr  = "You must entered details of you request, at least subject name"; 
						  }
					 }else{
						 $phoneErr = "Please enter your phone number."; 
						 
					}
					}else {
					$emailErr = "Email is required";  		
				}
				}else {
			    $lnameErr = "Your Last Name is required";
				}
			
			}else { 
			$fnameErr = "Your Name is required";
            }
			
		}
		
		if(isset($_POST["submit"])){
		
		if($check === TRUE){
		$sql= "INSERT INTO requestsform (fname, lname, email,phone, req_details, document , payment , college) VALUES ('$fname' , '$lname' , '$email' , '$phone' ,  '$requestdet'  , '$document' , '$payment' , '$colleage' )";
		
		if ($conn->query($sql) === TRUE) {
			echo "<script>alert('Request have been submit successfully.');</script>";
				} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
				}
			$conn->close();	
		}else{
			echo "<script>alert('*Fill the required fileds Please!');</script>";
		}
		}
		
		?>
				
				
				
				
				
		<fieldset>
		<legend style="font-size: 1.9em;"> Display all Requests </legend>
		<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">				
				<br>
				<button  id="dis"  name="display" class="btn btn-secondary">Display</button>
				<br><br>				
				<?php
				// define variables and set to empty values
		 $fname = $lname = $email = $phone =  $requestdet = $document = $payment = $colleage = "";
	
         if ($_SERVER["REQUEST_METHOD"] == "POST") {
		 if(isset($_POST["display"])){	
				$sql = "SELECT ID , fname, lname, email,phone, req_details, document,payment, college FROM requestsform";
				$result = $conn->query($sql);
				if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
				echo "Request ID : " . $row["ID"]. "<br>" . "Name : " . $row["fname"]. " ". $row["lname"] . "<br>" . "Request description : " . $row["req_details"]. "<br>" . "Document Type : " . $row["document"]. "<br>" . "Payment method : " . $row["payment"]. "<br>" . "Colleage Name : " . $row["colleage"]. "<br>";
				echo "______________________________________________________________________________________________ <br><br>";
				}
				} else {
				echo "0 results";
				}
				$conn->close();
				
			}
		 }
?>
			</form>	
		</fieldset>
		
		
		
	
		<footer>
		<p style="color: white;"> <b>Secondhand Books</b><br>
		Copyright 2020 Secondhand Books <br>		
		All right reserved for AJE enterprise <br>
		For more help contact us on :
		<a style="color: white;" href="SecondHandOrg@gmail.com">SecondHandOrg@gmail.com</a>
		</p>
		</footer>
		
		
		<script>

 function ConfirmFunction(){
	 
	 var r = confirm("Are you sure you want to submit the form?");
	
			if (r == false) {
			alert("Your Request failed to send!");
			return false;
 }
 }
 

    var hintArray = ["Enter your first name here in this input box" ,

                           "Enter your last name here in this input box" ,

    "Enter the phone number here in this input box" ,

                           "Enter the email here in this input box" ,

                           "Enter the requests details here in this input box" ,

                           "Check box if your document type is hard copy" ,

                           "Check box if your document type is PDF" ,

                           "Check box if your document type is word or powerpoint" ,

                           "Check box if your document type is others" ,

                           "Choose how you like to get your requests from these choices" ,

                           "Choose the related colleage from these choices" ,

                           "This button clear the form" ,""];

                           var hintText;

 

                           function init()

                           {

                                         hintText = document.getElementById("hintText");

                                         events(document.getElementById("Firstname"), 0);

                                         events(document.getElementById("Lastname"), 1);

                                         events(document.getElementById("phone"), 2);

                                         events(document.getElementById("Email"), 3);

                                         events(document.getElementById("details"), 4);

                                         events(document.getElementById("HC"), 5);

                                         events(document.getElementById("pdf"), 6);

                                         events(document.getElementById("w_OR_p"), 7);

                                         events(document.getElementById("others"), 8);

                                         events(document.getElementById("pay"), 9);

                                         events(document.getElementById("free"), 9);

                                         events(document.getElementById("any"), 9);

                                         events(document.getElementById("college"), 10);


                                         events(document.getElementById("reset"), 11);

                                         
										 var reqForm = document.getElementById("req");

 

                                         reqForm.addEventListener("reset",

                                         function()

                                         { return confirm("Are you sure you want to clear the form?");},false);

                           }

 

                           function events(formObject,hintNum)

                           {

                                         formObject.addEventListener("focus",

                                         function()

                                         { hintText.innerHTML = hintArray[hintNum];},false);

 

                                         formObject.addEventListener("blur",

                                         function()

                                         { hintText.innerHTML = hintArray[12];},false);

                           }

 

                                         window.addEventListener("load",init,false);

 

                           </script>
		</body>
		
</html>

