<?php
$servername = "localhost";
$username = "root";
$password = "mysql";

// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE second_hand";
if ($conn->query($sql) === TRUE) {
  echo "Database created successfully";
} else {
  echo "Error creating database: " . $conn->error;
}


// Create Tbales
$sql = "CREATE TABLE requestsform (
ID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
fname VARCHAR(30) NOT NULL,
lname VARCHAR(30) NOT NULL,
email VARCHAR(50),
phone INT(15),
req_details VARCHAR(100),
document VARCHAR(50),
payment VARCHAR(50),
colleage VARCHAR(50)
)";
if ($conn->query($sql) === TRUE) {
} else {
  echo "Error creating database: " . $conn->error;
}

// Create database
$sql = "CREATE TABLE uploadfiles (
ID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
fname VARCHAR(30) NOT NULL,
subject VARCHAR(30) NOT NULL,
category VARCHAR(20),
file BLOB
)";
if ($conn->query($sql) === TRUE) {
} else {
  echo "Error creating database: " . $conn->error;
}


$conn->close();
?>