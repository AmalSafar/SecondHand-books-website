<?php
$servername = "localhost";
$username = "root";
$password = "mysql";
$dbase = "second_hand";
// Create connection
$conn = new mysqli($servername, $username, $password , $dbase);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "";
?>
<!DOCTYPE html>
<html>
<head>
<title>Service</title>
<link rel="stylesheet"  type="text/css" href="style.css" />
<style> 
				  
		h1{color:black;
		position:absolute; left:300px; top: 50px;}
		p{ padding: 10px;
		color : black; 
		margin-left: 0px; 
		margin-top: 20px; 
		}
		.error {
			color: red;
			}
		
    </style>
</head>
<body class="body">
  <img id=heading src= "website.png" width="200" Height="200">
<div class="search-container">
		<form>
		<input type="text" placeholder="Search.." name="search">
		<button type="submit">Go!</button>
		</form>
		</div>
  <h1 style="color:black; position: absolute; left: 290px; top: 40px;">You are in services page!!</h1>
  <p style="position: absolute; left: 290px; top: 90px;">
  Welcome to our website!! You can see here our services.</p>

<br><br>

  <div class="topnav">
  	<a href="index.html">Home</a>
  	<a class="active" href="#services">Services</a>
		<a href="requests.php">Requests</a>
		
		
		<a href="Activity.html">My Activity </a>
		<a style="position:absolute; right:10px;">Log In</a>
		<a style="position:absolute; right:90px;" >Sign Up</a>
	</div>

<br><br><br><br>

<table class="main-content">
  <tbody>
  <tr>
  <td style="border: 1px;">
    <div class="computer" >
  <img id=computer src= "computer.png" width="250px" Height="250px" style="position: relative; left: 35px; top: 30px">
  <div class="list" style="position: relative; left: -15px; top: 70px">
    <ul>
      <div class="dropdown">
      <button class="btn">
      <li>Computer Science</li>
      </button>
      <div class="ddcontent">
      <div class="header">
        <h3>Section Sources</h3>
      </div>
      <div class="row">
        <div class="column">
          <h3>Books</h3>
          <a href="https://files.boazbarak.org/introtcs/lnotes_book.pdf">Introduction To Theoretical Computer Science</a>
          <a href="https://doc.lagout.org/science/0_Computer%20Science/Computer%20Science%20Handbook%2C%202nd%20Ed.pdf">Computer Science Handbook</a>
        </div>
        </div>
        </div>
        </div>

        <div class="dropdown">
        <button class="btn">
        <li>Information Technology</li>
        </button>
        <div class="ddcontent">
        <div class="header">
          <h3>Section Sources</h3>
        </div>
        <div class="row">
          <div class="column">
            <h3>Books</h3>
            <a href="http://sbmu.ac.ir/uploads/Oxford_English_for_Infomation_Technology.pdf">Oxford English for Infomation Technology</a>
            <a href="https://smkhaninfotech.files.wordpress.com/2013/10/csharp-4-and-net-4.pdf">C sharp 4 and NET 4</a>
          </div>
          </div>
          </div>
          </div>

          <div class="dropdown">
          <button class="btn">
          <li>Information Systems</li>
          </button>
          <div class="ddcontent">
          <div class="header">
            <h3>Section Sources</h3>
          </div>
          <div class="row">
            <div class="column">
              <h3>Books</h3>
              <a href="http://docshare01.docshare.tips/files/31709/317098453.pdf">Introduction to Information Systems</a>
              <a href="https://drive.uqu.edu.sa/_/fbshareef/files/principles%20of%20information%20systems%209th%20-stair,%20reynolds.pdf">PRINCIPLES OF INFORMATION SYSTEMS</a>
            </div>
            </div>
            </div>
            </div>
    </ul>
  </div>
  </div>
</td>

<td style="border: 1px;">
  <div class="sciences" >
  <img id=sciences src= "sciences.png" width="200px" Height="200px" style="position: relative; left: 60px; top: 55px">
  <div class="list" style="position: relative; left: -50px; top: 5px" style="border: 1px;">
    <ul>
      <div class="dropdown">
      <button class="btn">
      <li>Biology</li>
      </button>
      <div class="ddcontent">
      <div class="header">
        <h3>Section Sources</h3>
      </div>
      <div class="row">
        <div class="column">
          <h3>Books</h3>
          <a href="http://biology.org.ua/files/lib/Raven_Johnson_McGraw-Hill_Biology.pdf">The Science of Biology</a>
          <a href="http://dl.booktolearn.com/ebooks2/science/biology/9781454915331_The_Biology_Book_cdd2.pdf">The Biology Book</a>
        </div>
        </div>
        </div>
        </div>

        <div class="dropdown">
        <button class="btn">
        <li>Mathematics</li>
        </button>
        <div class="ddcontent">
        <div class="header">
          <h3>Section Sources</h3>
        </div>
        <div class="row">
          <div class="column">
            <h3>Books</h3>
            <a href="https://gifs.africa/wp-content/uploads/2020/05/Mathematics-Practice-Book.pdf">Mathematics Practice</a>
            <a href="https://www.math.stonybrook.edu/~aknapp/download/b2-alg-inside.pdf">Basic Algebra</a>
          </div>
          </div>
          </div>
          </div>

          <div class="dropdown">
          <button class="btn">
          <li>Physics</li>
          </button>
          <div class="ddcontent">
          <div class="header">
            <h3>Section Sources</h3>
          </div>
          <div class="row">
            <div class="column">
              <h3>Books</h3>
              <a href="https://webhome.phy.duke.edu/~rgb/Class/intro_physics_1/intro_physics_1.pdf">Introductory Physics</a>
              <a href="http://khoavatly.dhsptn.edu.vn/Files/1000_Solved_Problem_in_Modern_Physics.pdf">1000 Solved Problems in Modern Physics</a>
            </div>
            </div>
            </div>
            </div>

            <div class="dropdown">
            <button class="btn">
            <li>Chemistry</li>
            </button>
            <div class="ddcontent">
            <div class="header">
              <h3>Section Sources</h3>
            </div>
            <div class="row">
              <div class="column">
                <h3>Books</h3>
                <a href="https://openedgroup.org/books/Chemistry.pdf">Introduction to Chemistry</a>
                <a href="https://web.ung.edu/media/Chemistry2/Chemistry-LR.pdf">Chemistry</a>
              </div>
              </div>
              </div>
              </div>

              <div class="dropdown">
              <button class="btn">
              <li>Statistics</li>
              </button>
              <div class="ddcontent">
              <div class="header">
                <h3>Section Sources</h3>
              </div>
              <div class="row">
                <div class="column">
                  <h3>Books</h3>
                  <a href="http://onlinestatbook.com/Online_Statistics_Education.pdf">Introduction to Statistics</a>
                  <a href="http://www.utstat.toronto.edu/mikevans/jeffrosenthal/book.pdf">Probability and Statistics</a>
                </div>
                </div>
                </div>
                </div>

                  <div class="dropdown">
                  <button class="btn">
                  <li>Biochemistry</li>
                  </button>
                  <div class="ddcontent">
                  <div class="header">
                    <h3>Section Sources</h3>
                  </div>
                  <div class="row">
                    <div class="column">
                      <h3>Books</h3>
                      <a href="https://labalbaha.files.wordpress.com/2014/04/fundamentals-of-biochemistry.pdf">Fundamentals of Biochemistry</a>
                      <a href="https://library.um.edu.mo/ebooks/b28050745.pdf">Biochemistry</a>
                    </div>
                    </div>
                    </div>
                    </div>
    </ul>
  </div>
  </div>
</td>
</tr>
</tbody>
</table>

<br><br><br><br><br><br>

<table class="main-content" >
  <tr >
    <td class="Economics-and-Administration" style="border: 1px;" >
  <img id=Economics-and-Administration src= "Economics-and-Administration.png" width="250px" Height="250px" style="position: relative; left: 110px; top: 65px">
  <div class="list" style="position: relative; left: -55px; top: 2px ;">
    <ul>
      <div class="dropdown">
      <button class="btn">
      <li>Business Administration</li>
      </button>
      <div class="ddcontent">
      <div class="header">
        <h3>Section Sources</h3>
      </div>
      <div class="row">
        <div class="column">
          <h3>Books</h3>
          <a href="https://2012books.lardbucket.org/pdfs/an-introduction-to-business-v1.0.pdf">An Introduction to Business</a>
          <a href="http://cbseacademic.nic.in/web_material/Curriculum/Vocational/2018/Business%20Administration/XII/Business%20Admin-%20XII.pdf">Business Administration</a>
        </div>
        </div>
        </div>
        </div>

        <div class="dropdown">
        <button class="btn">
        <li>Economics</li>
        </button>
        <div class="ddcontent">
        <div class="header">
          <h3>Section Sources</h3>
        </div>
        <div class="row">
          <div class="column">
            <h3>Books</h3>
            <a href="http://pombo.free.fr/samunord19.pdf">ECONOMICS</a>
            <a href="http://www.library.fa.ru/files/Marshall-Principles.pdf">Principles of Economics</a>
          </div>
          </div>
          </div>
          </div>

            <div class="dropdown">
            <button class="btn">
            <li>Accounting</li>
            </button>
            <div class="ddcontent">
            <div class="header">
              <h3>Section Sources</h3>
            </div>
            <div class="row">
              <div class="column">
                <h3>Books</h3>
                <a href="http://womlib.ru/book/Financial_Accounting_And_Its_Environment.pdf">Financial Accounting and Its Environment</a>
                <a href="https://2012books.lardbucket.org/pdfs/business-accounting.pdf">Business Accounting</a>
              </div>
              </div>
              </div>
              </div>

                <div class="dropdown">
                <button class="btn">
                <li>Health Services and Hospitals Management</li>
                </button>
                <div class="ddcontent">
                <div class="header">
                  <h3>Section Sources</h3>
                </div>
                <div class="row">
                  <div class="column">
                    <h3>Books</h3>
                    <a href="https://library.oapen.org/bitstream/id/ba37c4a5-5b76-414d-a380-264fcceab1a8/625765.pdf">Managing Modern Healthcare</a>
                  </div>
                  </div>
                  </div>
                  </div>

                  <div class="dropdown">
                  <button class="btn">
                  <li>Management Information Systems</li>
                  </button>
                  <div class="ddcontent">
                  <div class="header">
                    <h3>Section Sources</h3>
                  </div>
                  <div class="row">
                    <div class="column">
                      <h3>Books</h3>
                      <a href="https://dinus.ac.id/repository/docs/ajar/Kenneth_C.Laudon,Jane_P_.Laudon_-_Management_Information_Sysrem_13th_Edition_.pdf">Management Information Systems</a>
                      <a href="http://www.pearsonmiddleeastawe.com/pdfs/SAMPLE-MIS.pdf">Management Information Systems-Managing the Digital Firm</a>
                    </div>
                    </div>
                    </div>
                    </div>

                    <div class="dropdown">
                    <button class="btn">
                    <li>financial</li>
                    </button>
                    <div class="ddcontent">
                    <div class="header">
                      <h3>Section Sources</h3>
                    </div>
                    <div class="row">
                      <div class="column">
                        <h3>Books</h3>
                        <a href="http://unipub.lib.uni-corvinus.hu/3842/1/pfi-briefings.pdf">Basics of Finance</a>
                        <a href="https://2012books.lardbucket.org/pdfs/individual-finance.pdf">Individual Finance</a>
                      </div>
                      </div>
                      </div>
                      </div>

                      <div class="dropdown">
                      <button class="btn">
                      <li>Marketing</li>
                      </button>
                      <div class="ddcontent">
                      <div class="header">
                        <h3>Section Sources</h3>
                      </div>
                      <div class="row">
                        <div class="column">
                          <h3>Books</h3>
                          <a href="https://htbiblio.yolasite.com/resources/Marketing%20Book.pdf">The Marketing Book</a>
                          <a href="https://textbookequity.org/Textbooks/Burnett_introdmarketingCCM.pdf">Introducing Marketing</a>
                          <a href="https://2012books.lardbucket.org/pdfs/marketing-principles-v2.0.pdf">Marketing principles</a>
                        </div>
                        </div>
                        </div>
                        </div>

                        <div class="dropdown">
                        <button class="btn">
                        <li >Human Resources Management</li>
                        </button>
                        <div class="ddcontent">
                        <div class="header">
                          <h3>Section Sources</h3>
                        </div>
                        <div class="row">
                          <div class="column">
                            <h3>Books</h3>
                            <a href="http://www.opentextbooks.org.hk/system/files/export/32/32088/pdf/Human_Resource_Management_32088.pdf">Human Resource Management</a>
                            <a href="https://openaccess.leidenuniv.nl/bitstream/handle/1887/22381/ASC-075287668-3030-01.pdf">Fundamentals of human resource management</a>
                          </div>
                          </div>
                          </div>
                          </div>
    </ul>
  </div>
</td>
</tr>
</table>
	<br><br><br><br>

	<div class="uploudH">
    <h2>You can upload your sources here..</h2>
	</div>
	
	<form method="POST" id="uploudForm" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
		<p><span class="error">* Required field</span></p>
		<div class="uploud">
			<div class="uploudF">
			<label for="name">Name:</label><span class="error">* <?php echo $fnameErr;?></span>
			<br>
			<input type="text" id="name" name="name" value="" placeholder="Enter your name">
			</div>
			<div class="uploudF">
			<label for="name">Subject:</label><span class="error">* <?php echo $subjectErr;?></span>
			<br>
			<input type="text" id="Subject" name="Subject" value="" placeholder="Enter the subject">
			</div>
			<div class="uploudF">
			<label for="name">Category:</label><span class="error">* <?php echo $categoryErr;?></span>
			<br>
			<input type="radio" id="Category1" name="Category" value="Electronic Book">Electronic Book<br>
			<input type="radio" id="Category2" name="Category" value="Power Point - slides">Power Point - slides<br>
			<input type="radio" id="Category3" name="Category" value="Hard copy book">Hard copy book<br>
			<input type="radio" id="Category3" name="Category" value="Hard copy slides">Hard copy slides<br>
			</div>
			<div class="uploudF">
			<span class="error">* <?php echo $fileErr;?></span>
			<input type="file" id="File" name="file">
			<br>
			<br>
			<button  style="margin-left:10px;" id="submit"   name="submit"  type="submit" class="btn btn-secondary" onclick=" return ConfirmFunction(); false">upload</button>
			<p id = "hintText"> </p>
			</div>
		</div>
	</form>
  
 <?php
 
 function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
	}
 
 $file_name  = ""; 
 $fnameErr = $subjectErr = $categoryErr = $fileErr = "";
 $check = false;  
 
 
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
		
		if (!empty($_FILES['file'])){
			echo "file";
		$file_name = $_FILES['file']['name'];
		$file_type = $_FILES['file']['type'];
		$file_size = $_FILES['file']['size'];
		$file_tem_loc = $_FILES['file']['tmp_name'];
		
		if (is_uploaded_file($file_tem_loc)){
		if (move_uploaded_file($file_tem_loc, "uploads/$file_name")){
			
		}
		}
		 if (!empty($_POST['name'])) {
			    $fname = test_input($_POST['fname']);
			     if (!empty($_POST['Subject'])) {
					$subject = test_input($_POST['Subject']);
					 
					 if (isset($_POST['Category'])) { 
					 $category = test_input($_POST['Category']);
					 $check = TRUE;
					 }else{
						$categoryErr = "Please Select a category."; 
					 }
				 }else{
					 $subjectErr = "Please Select a subject."; 
				 }
				}else{
			 $fnameErr = "Please Enter Your Name."; 
		 }
		}else{
			$fileErr = "Attach a file please"; 
		}
 }
 
		if(isset($_POST["submit"]) ){ 
		 if ($check === TRUE && $nullCheck === TRUE){
		$sql = "INSERT INTO uploadfiles( fname , subject, category, file) VALUES('$fname', '$subject' , '$category' ,'$file_name')";
		if(mysqli_query($conn,$sql)){
			echo "<script>alert('Thank You for you support! Your material uploaded successfully.');</script>";
		}
		else{
		echo "Error: " . $sql . "<br>" . $conn->error;
		}
	 }else{
		 echo "<script>alert('*fill the required fileds please !');</script>";
	 }

 }
   
		
		
 
?>  
		<footer>
		<p style="color: white;"> <b>Secondhand Books</b><br>
		Copyright 2020 Secondhand Books <br>		
		All right reserved for AJE enterprise <br>
		For more help contact us on :
		<a style="color: white;" href="SecondHandOrg@gmail.com">SecondHandOrg@gmail.com</a>
		</p>
		</footer>
		
	
		<script>
		
		 function ConfirmFunction(){
	 
	 var r = confirm("Are you sure you want to submit the form?");
	
			if (r == false) {
			alert("Your Request failed to send!");
			return false;
 }
 }
		
		
		
var hintArray = ["Enter your name here in this input box" ,
"Enter the subject here in this input box" ,
"Choose Category of your file from these choices" ,
"This button to uplode your file" , ""];
var hint;

function init()
{
	hintText = document.getElementById("hintText");
	events(document.getElementById("name"), 0);
	events(document.getElementById("Subject"), 1);
	events(document.getElementById("Category1"), 2);
	events(document.getElementById("Category2"), 2);
	events(document.getElementById("Category3"), 2);
	events(document.getElementById("File"), 3);
	
}

function events(formObject,hintNum)
{
	formObject.addEventListener("focus",
	function()
	{ hintText.innerHTML = hintArray[hintNum];},false);

	formObject.addEventListener("blur",
	function()
	{ hintText.innerHTML = hintArray[4];},false);
 }

	window.addEventListener("load",init,false);
</script>
		
</body>
</html>